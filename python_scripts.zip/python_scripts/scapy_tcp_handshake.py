#!/usr/bin/python
from scapy.all import *

sportt = random.randint(1024,65535)

# SYN
ip=IP(src='10.232.11.150',dst='10.232.11.146')
SYN=TCP(sport=sportt,dport=21,flags='S',seq=1000)
SYNACK=sr1(ip/SYN)
SYNACK.display()
# SYN-ACK
ACK=TCP(sport=sportt, dport=21, flags='A', seq=SYNACK.ack, ack=SYNACK.seq + 1)
send(ip/ACK)
ACK.display()
