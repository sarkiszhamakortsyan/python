import socket 
s = socket.socket() 

s.connect (("10.232.11.137", 22))
print s.recv(1024) 
s.close()
