import socket 
s = socket.socket() 
s.settimeout(2)
try:

	s.connect (("10.232.11.137", 80)) 
	print s.recv(1024)
	s.close()
except socket.error as err:
	print err
