import socket 
s = socket.socket() 
s.settimeout(2)

target='10.232.11.137'

s.connect ((target, 80))

req = """

u=a1&p=1"""


print 'Sending: '
print req
s.send(req)

print 'Received: '
print s.recv(1024)

s.close()
