import socket 
s = socket.socket() 

try:

	s.connect (("10.232.11.137", 23))
	print s.recv(1024)
	s.close() 
except socket.error as err:
	print err
