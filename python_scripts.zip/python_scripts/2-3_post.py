import socket 
s = socket.socket() 
s.settimeout(2)

target='10.232.11.137'

s.connect ((target, 80))

req = """POST / HTTP/1.1
Host: 10.232.11.137
Connection: keep-alive
Content-Length: 8
Cache-Control: max-age=0
Origin: http://10.232.11.137
Upgrade-Insecure-Requests: 1
Content-Type: application/x-www-form-urlencoded
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3
Referer: http://10.232.11.137/
Accept-Language: en-US,en;q=0.9
Cookie: FDX=1ihgc8xm574pu631fezajrawd"""


print 'Sending: '
print req
s.send(req)

print 'Received: '
print s.recv(1024)

s.close()
